import { Component, OnInit } from '@angular/core';

@Component({
	selector: 'app-trending',
	templateUrl: './trending.page.html',
	styleUrls: ['./trending.page.scss'],
})
export class TrendingPage implements OnInit {
	constructor() {}

	ngOnInit() {}
}
